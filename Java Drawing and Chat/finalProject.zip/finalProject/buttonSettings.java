package finalProject;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Jerry on 3/28/2016.
 */
public class buttonSettings {
    public buttonSettings(JButton a, JButton b, JButton c, JButton d, JButton e) {
        a.setFont(new Font("Arial", Font.BOLD, 20));
        b.setFont(new Font("Arial", Font.BOLD, 20));
        c.setFont(new Font("Arial", Font.BOLD, 20));
        d.setFont(new Font("Arial", Font.BOLD, 20));
        e.setFont(new Font("Arial", Font.BOLD, 20));

    }
}
