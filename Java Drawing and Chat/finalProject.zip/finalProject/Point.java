package finalProject;

public class Point {

    int x, y;

    public Point(int a, int b) {
        x = a;
        y = b;

    }
}
